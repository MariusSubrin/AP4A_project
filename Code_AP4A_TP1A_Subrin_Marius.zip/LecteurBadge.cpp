#include "LecteurBadge.h"

int lecteur_badge::id_memory = 0; //Definie l'id initial de mes lecteurs de badges
