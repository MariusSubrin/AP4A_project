#ifndef SCHEDULER_H
#define SCHEDULER_H



void simulation(); //initie une demande d'accès


#endif //SCHEDULER_H
