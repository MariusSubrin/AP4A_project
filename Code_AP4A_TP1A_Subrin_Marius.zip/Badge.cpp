#include "Badge.h"

int badge::id_memory = 0; //Definie l'id initial de mes badges


